<?php
namespace Training2\Specific404Page\Controller\NoRoute;

class Category extends \Training2\Specific404Page\Controller\NoRoute
{

}