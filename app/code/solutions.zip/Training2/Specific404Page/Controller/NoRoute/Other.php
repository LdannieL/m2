<?php
namespace Training2\Specific404Page\Controller\NoRoute;

class Other extends \Training2\Specific404Page\Controller\NoRoute
{

}