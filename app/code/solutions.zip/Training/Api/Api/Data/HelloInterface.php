<?php

namespace Training\Api\Api\Data;

interface HelloInterface {

    /**                                                                                                                                    
     * Hello method                                                                                                                        
     *                                                                                                                                     
     * @return string|null                                                                                                                 
     */
    public function sayHello();
}
