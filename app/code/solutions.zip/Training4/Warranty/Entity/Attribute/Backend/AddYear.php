<?php

namespace Training4\Warranty\Entity\Attribute\Backend;

class AddYear extends 
    \Magento\Eav\Model\Entity\Attribute\Backend\AbstractBackend
{

    /**
     * Before save method
     *
     * @param \Magento\Framework\DataObject $object
     * @return $this
     */
    public function beforeSave($object)
    {
        parent::beforeSave($object);
        $value = $this->getAttribute()->getValue();
        // $value = $object->getData($this->getAttribute()->getValue());
        //$value = $object->getValue();
        $value = $value . ' Year';
        $this->getAttribute()->setValue($value);
        //$object->setValue($value);

        return $this;
    }
}