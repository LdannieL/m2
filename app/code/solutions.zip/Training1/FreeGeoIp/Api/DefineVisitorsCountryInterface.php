<?php

namespace Training1\FreeGeoIp\Api;

interface DefineVisitorsCountryInterface
{
    /**
     * @return string
     */
    public function getCountry();
}