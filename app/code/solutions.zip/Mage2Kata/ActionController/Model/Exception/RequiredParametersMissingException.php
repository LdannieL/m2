<?php
 
namespace Mage2Kata\ActionController\Model\Exception;
 
class RequiredParametersMissingException extends \RuntimeException
{
}