<?php
 
use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Mage2Kata_DiConfig', __DIR__);
