/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*jshint browser:true jquery:true*/
define([
    "jquery"
], function($){
    "use strict";

    return function(config, element) {
        alert(config.full_action_name);
    }
});