<?php
namespace Pulsestorm\SimpleUiComponent\Block\Adminhtml;
class Main extends \Magento\Backend\Block\Template
{
    function _prepareLayout(){}
}
