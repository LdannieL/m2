<?php
namespace Pulsestorm\Helloworld\Plugin\Magento\Framework\Logger;
class Monolog
{
    //function beforeMETHOD($subject, $arg1, $arg2){}
    //function aroundMETHOD($subject, $procede, $arg1, $arg2){return $proceed($arg1, $arg2);}
    //function afterMETHOD($subject, $result){return $result;}
}
