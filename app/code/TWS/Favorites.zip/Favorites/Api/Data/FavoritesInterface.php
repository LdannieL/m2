<?php
namespace TWS\Favorites\Api\Data;
interface FavoritesInterface 
{
}