define([
    "jquery",
    "favorites"
], function($, favorites) {
    "use strict";
        //creating jquery widget
    //     $.widget('favwidget.js', {
    //         _create: function() {
    //             //for exmple, you can create some click event or something else
    //             this.element.on('click', function(e){
    //                 alert("You click on element: " + e.target);
    //             });
    //         }
 
    //     });
 
    // return $.favwidget.js;
});


