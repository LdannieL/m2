<?php
namespace Pulsestorm\Pestleform\Model;
interface ThingInterface 
{

}