<?php
namespace Pulsestorm\KnockoutTutorial\Block;
class Main extends \Magento\Framework\View\Element\Template
{
    function _prepareLayout(){}
}
