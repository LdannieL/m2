<?php
namespace Pulsestorm\ToDoCrud\Model;
interface TodoItemInterface 
{

}