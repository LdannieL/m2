<?php
namespace Training2\Specific404Page\Controller\NoRoute;

class Product extends \Training2\Specific404Page\Controller\NoRoute
{

}