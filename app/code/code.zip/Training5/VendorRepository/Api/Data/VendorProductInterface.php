<?php
namespace Training5\VendorRepository\Api\Data;
interface VendorProductInterface 
{

}