<?php
namespace Training5\VendorRepository\Api\Data;
interface VendorInterface 
{
	/**
     * @return string|null
     */
	public function sayHello();
}