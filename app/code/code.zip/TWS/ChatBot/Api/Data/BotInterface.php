<?php
namespace TWS\ChatBot\Api\Data;
interface BotInterface 
{
}